# -*- coding: utf-8 -*-
# %%
'''Basic Grammar - ch07.py'''
'''7. 제어문'''
'''(2) 조건문 - if, 인라인if'''
# %%
'''1) 개요'''
# 7-(2)-1)-1
points = 950
up_grade = ""

if points >= 900:
    up_grade = "승급"
else:
    up_grade = "유지"

print("승급 여부 : " + up_grade)
# %%
# 7-(2)-1)-2
points = 950
upgrade_stu = False

if points >= 900:
    upgrade_stu = True

print("승급 여부 :", upgrade_stu)
# %%
'''2) 기본 if문 : if-else'''
# 7-(2)-2)-1
# 순서1
jum = int(input("점수 입력 : "))

# 순서2
if jum >= 90:
    result = "지옥훈련"
else:
    result = "휴가"

# 순서3
print("입력 점수: " + str(jum) + "점, 결과: " + result)
# %%
# 7-(2)-2)-2
'''문제해결 7-2-1)'''
# 순서1
pin_money = int(input("용돈 입력 : "))
goods_price = int(input("굿즈 가격 입력 : "))

# 순서2
if pin_money >= goods_price:
    print("구매함")
    pin_money -= goods_price
else:
    print("용돈부족")

# 순서3
print("용돈 잔액 :", pin_money)
# %%
# 7-(2)-2)-3
'''문제해결 7-2-2)'''
# 순서1
kuk_jum = int(input("국어점수 입력 : "))
su_jum = int(input("수학점수 입력 : "))

# 순서2
if kuk_jum >= 90 and su_jum >= 90:
    print("우수")
else:
    print("보통")

# %%
# 7-(2)-2)-4
'''문제해결 7-2-3)'''
# 순서1
input_id = input("아이디 입력 : ")
input_pass = input("비밀번호 입력 : ")

# 순서2
if input_id == "admin" and input_pass == "#12345be":
    print("로그인 성공")
else:
    print("로그인 실패")

# %%
'''3) 다중 if문 : if-elif-else'''
# 7-(2)-3)-1
rank_jum = int(input("랭크점수 입력 : "))

if rank_jum >= 90:
    rank = "골드"
elif rank_jum >= 70:
    rank = "실버"
else:
    rank = "브론즈"

print("랭크 : " + rank)
# %%
# 7-(2)-3)-2
'''문제해결 7-3-1)'''
# 순서1
jum = int(input("점수 입력 : "))

# 순서2
if jum >= 90:
    rating = "A"
elif jum >= 80:
    rating = "B"
elif jum >= 70:
    rating = "C"
elif jum >= 60:
    rating = "D"
else:
    rating = "F"

# 순서3
print("점수 :", jum, ", 평가 :", rating)
# %%
# 7-(2)-3)-3
'''문제해결 7-3-2)'''
# 순서1
real_id = "admin"
real_pass = "#12345be"

# 순서2
input_id = input("아이디 입력 : ")
input_pass = input("비밀번호 입력 : ")

# 순서3
if input_id == real_id and input_pass == real_pass:
    print("로그인 성공")
elif input_id == real_id and input_pass != real_pass:
    print("비밀번호 다름")
else:
    print("해당 아이디 없음")

# %%
# 7-(2)-3)-4
'''문제해결 7-3-3)'''
# 순서1
dow_var = int(input("0~6사이의 요일 값 입력 : "))

# 순서2
if dow_var >= 1 and dow_var <= 4:
    dow_des = "평일"
elif dow_var == 5:
    dow_des = "불금"
elif dow_var == 0 or dow_var == 6:
    dow_des = "주말"

# 순서3
print("요일 값 : %d, %s" % (dow_var, dow_des))
# %%
'''4) 인라인if'''
# 7-(2)-4)-1
# 순서1
data_int = int(input("값 입력:"))

# 순서2
num = 12 if data_int == 10 else 13

# 순서3
print(num)
# %%
'''(3) 반복문 - for, while'''
'''2) for문'''
# 7-(3)-2)-1
# 순서1
list_leagues = ["LCK", "LPL", "LEC", "LCS"]

# 순서2
for i, my_league in enumerate(list_leagues):
    print(i, my_league)
# %%
# 7-(3)-2)-2
# 순서1
sys_dat = {"id": ("admin", "root", "dba"),
           "pass": ("1111", "2222", "3333"),
           "roll": (1, 2, 3)}

# 순서2
for key, val in sys_dat.items():
    print(key, val)
# %%
# 7-(3)-2)-3
for i in range(1, 11):
    print(i, end=' ')
# %%
# 7-(3)-2)-4
'''문제해결 7-4-1)'''
# 순서1
user_dict = {}

# 순서2
id_list = input("아이디 입력 : ").split()
pass_list = input("비밀번호 입력 : ").split()

# 순서3
for key, val in zip(id_list, pass_list):
    user_dict[key] = val

# 순서4
print(user_dict)
# %%
# 7-(3)-2)-5
'''문제해결 7-4-2)'''
# 순서1
sum_val = 0

# 순서2
list_val = map(float, input("값 입력: ").split())

# 순서3
for val in list_val:
    sum_val += val

# 순서4
print("합계: %.2f" % (sum_val))
# %%
# 7-(3)-2)-6
'''문제해결 7-4-3)'''

# 순서1
str_list = ["Vesemir", "Geralt", "Eskel", "Lambert", "Berenga"]

# 순서2
for val in str_list:
    # 순서3
    if len(val) % 2 == 0:
        print("%s, %d개 : %s" % (val, len(val), "짝수"))
    else:
        print("%s, %d개 : %s" % (val, len(val), "홀수"))
# %%
'''3) while문 : while 조건식'''
# 7-(3)-3)-1
c = 1

# 순서2
while c <= 5:
    print("c =", c)
    c += 1

# %%
# 7-(3)-3)-2
'''문제해결 7-5-1)'''
# 순서1
result_str = ""

# 순서2
while 1:
    input_str = input("문자열 입력: ")
    if input_str == "quit":
        break
    result_str += input_str

# 순서3
print(result_str)
# %%
# 7-(3)-3)-3
# 순서1
for x in range(10):
    if x == 5:
        print("값이 5여서 탈출")
        break
    print("x =", x)

# %%
# 7-(3)-3)-4
'''문제해결 7-5-2)'''
# 순서1
CRUSH_VAL = 50
crush_stu = True

# 순서2
health_val = int(input("초기체력 입력: "))
health_val = health_val if health_val >= 0 else 0

# 순서3
while True:
    if health_val == 0:
        print("game over!!")
        break
    if crush_stu:
        health_val -= CRUSH_VAL
        health_val = health_val if health_val >= 0 else 0
        print("남은 체력: ", health_val)

# %%
'''반복문의 성능비교'''
# 7-(3)-4)-1
'''
# 리스트 컴프리헨션, for, while 속도 비교
# 리스트 컴프리헨션
%%timeit
mylist = [2 * x * x for x in range(5)]

# %%
# for문
%%timeit
mylist = []
for x in range(5):
    mylist.append(2*x*x)
# %%
# while문
%%timeit
x = 0
mylist = []
while x < 5:
    mylist.append(2*x*x)
    x += 1
# %%
# 7-(3)-4)-2
# for와 while 속도 비교
# for
%%timeit
mylist = [1, 2, 3, 4, 5]
for x in mylist:
    x
# %%
# while
%%timeit
mylist = [1, 2, 3, 4, 5]
x = 0
while x < 5:
    mylist[x]
    x += 1
'''
# %%
'''(4) 에러제어 – try~except'''
'''1) 개요'''
# 7-(4)-1)-1
# 순서1
try:
    answer = 1 / 0  # 에러 발생
    print(answer)
except ZeroDivisionError:
    print("오류발생")

# 순서2
print("에러가 처리되면 나머지 작업도 제대로 수행됨")
# %%
'''2) except pass'''
# 7-(4)-2)-1
# 순서1
try:
    answer = 1 / 0  # 에러 발생
    print(answer)
except:
    pass

# 순서2
print("에러가 처리되면 나머지 작업도 제대로 수행됨")
# %%
'''3) 파이썬 버전에 따라 임포트할 라이브러리이름이 다른 경우 제어'''
# 7-(4)-3)-1
# 순서1
try:
    import tkinter as tk
except ImportError:
    import Tkinter as tk

# 순서2
root = tk.Tk()
lbl_info = tk.Label(root, text="test")
lbl_info.grid(row=0, column=0)
root.mainloop()
# %%
'''(5) 리소스 해제 - with'''
# 7-(5)-1
with open("Khalani.txt", "r") as f:
    print(f.readlines())
# %%
# 7-(5)-2
with open("bearlist.txt", "w") as f:
    f.write("4 o'clock\nscenery\nwinter bear\nsweet night\nsnow flower\n")
