# -*- coding: utf-8 -*-
"""
x + y + math.pow(x, y) 계산
"""

import math


def my_fun(x, y):  # my_fun()함수 정의
    return x + y + math.pow(x, y)


if __name__ == '__main__':
    x, y = 5.0, 3.0
    print("my_fun(x, y) = %d" % my_fun(x, y))
