# -*- coding: utf-8 -*-
# %%
'''Basic Grammar - ch06.py'''
''' 6. 여러 값을 저장하는 타입 – 리스트, 튜플, 세트, 딕셔너리 타입별 처리'''
'''(1) 개요'''
# %%
# 6-(1)-1
a_list = [1, 2, 'a']
print(a_list)
# %%
# 6-(1)-2
a_tuple = (1, 2, 'a')
print(a_tuple)
# %%
# 6-(1)-3
a_set = {10, 20, 30}
print(a_set)
# %%
# 6-(1)-4
a_dic = {"id": "abcd", "jum": 80}
print(a_dic)
# %%
'''(2) 리스트 - []'''
'''1) 리스트 선언'''
# 6-(2)-1)-1
data_list = ["서울시", 1, "경기도", 1.2, "인천시", 0.3]
print(data_list)
# %%
# 6-(2)-1)-2
empty_list = []
print(empty_list)

empty_list.append(100)
print(empty_list)
# %%
# 6-(2)-1)-3
# 함수목록을 값으로 갖는 리스트


def my_add(x, y):  # my_add()함수 정의
    return x + y


def a():  # a()함수 정의
    return 1


x, y = 5.0, 6.0
fun_list = [my_add, a]  # 함수를 내용으로 갖는 리스트
print(fun_list[0](x, y))
print(fun_list[1]())
# %%
'''문제해결 6-2-1'''
# 6-(2)-1)-4

# 순서1
chr_list = input("문자열 입력: ").split()

# 순서2
print("입력받은 리스트 값 :", chr_list)
# %%
'''2) 리스트 사용 : 원소 값을 변경하거나 얻어냄'''
# 6-(2)-2)-1
num_list = [11, 12, "test", 99, [1, 2]]
print(num_list)

num_list[1] = 7  # num_list[1]의 값을 7로 변경
print(num_list)
# %%
# 6-(2)-2)-2
num_list = [11, 12, "test", 99, [1, 2]]
print(num_list)

num_list[-1] = 77  # num_list[-1]의 값을 77로 변경
print(num_list)
# %%
# 6-(2)-2)-3
num_list = [11, 12, "test", 99, [1, 2]]
print(num_list)

print(num_list[0])  # num_list[0]값 얻어내기
print(num_list[2])  # num_list[2]값 얻어내기
print(num_list[-1])  # num_list의 마자막원소값 얻어내기
# %%
'''3) 리스트의 여러 원소 값 얻어내기 - :(슬라이스)사용'''
# 6-(2)-3)-1
data2 = [20, 22, 30, 25, 28]
print(data2[1:3])
# %%
# 6-(2)-3)-2
data2 = [20, 22, 30, 25, 28]
print(data2[2:])
# %%
# 6-(2)-3)-3
data2 = [20, 22, 30, 25, 28]
print(data2[:3])
# %%
# 6-(2)-3)-4
data2 = [20, 22, 30, 25, 28]
print(data2[:])
print(data2)
# %%
'''4) 리스트에 원소 추가 - append()'''
# 6-(2)-4)-1
data2 = [20, 22, 30, 25, 28]
data2.append(99)
print(data2)
# %%
'''5) 리스트에 원소 삽입 – insert()'''
# 6-(2)-5)-1
data2 = [20, 22, 30, 25, 28]
data2.insert(3, 99)
print(data2)
# %%
'''6) 리스트의 원소 삭제 – del, remove()'''
# 6-(2)-6)-1
data2 = [20, 22, 30, 25, 28]
del data2[1]
print(data2)
# %%
# 6-(2)-6)-2
data2 = [20, 22, 30, 25, 28]
data2.remove(30)
print(data2)
# %%
# 6-(2)-6)-3
data3 = [1, 1, 2, 2, 3]
data3.remove(1)
print(data3)
# %%
'''7) range()함수를 사용한 숫자 값 범위 생성'''
# 6-(2)-7)-1
range(10)
# %%
# 6-(2)-7)-2
list(range(10))
# %%
'''8) 리스트 컴프리헨션 - 리스트를 효과적으로 생성 '''
# 6-(2)-8)-1
cmp_list = [2*x*x for x in range(5)]
print(cmp_list)
# %%
# 6-(2)-8)-2
data_list = [1, 2, 3, 4, 5, 6]
data2_list = [x*2 for x in data_list if x % 2 == 0]  # 짝수만 2배해서 새리스트
print(data2_list)
# %%
'''9) enumerate()함수 - 리스트에서 인덱스와 값을 같이 얻어냄 '''
# 6-(2)-9)-1
dates_3 = [5, 15, 90]
print(enumerate(dates_3))
print(list(enumerate(dates_3)))
# %%
# 6-(2)-9)-2
for idx, val in enumerate(dates_3):  # idx - 인덱스, val - 값
    print(idx, val)
# %%
'''10) enumerate()함수 - 리스트에서 인덱스와 값을 같이 얻어냄 '''
# 6-(2)-10)-1
print(zip(range(5), range(1, 10, 2)))
print(list(zip(range(5), range(1, 10, 2))))
# %%
# 6-(2)-10)-2
print("range(5)의 원소 :", list(range(5)))
print("range(1, 10, 2)의 원소 :", list(range(1, 10, 2)))

new_list2 = [x + y for x, y in zip(range(5), range(1, 10, 2))]

print("new_list2 리스트의 원소 :", new_list2)
# %%
'''문제해결 6-2-2'''
# 6-(2)-10)-3

# 순서1
date_list = ["2013-02", "2014-02", "2015-02"]

# 순서2
du_list = map(int, input("3개의 정수 입력: ").split())

# 순서3
print(list(zip(date_list, du_list)))
# %%
'''(3) 튜플 - ()'''
# 6-(3)-1
adm_id = ("admin", "root", "dba")
print(adm_id)
# %%
# 6-(3)-2
adm_id = ("admin", "root", "dba")
print(adm_id[1])
# %%
# 6-(3)-3
print(tuple(zip(['geralt', 'yennefer', 'cirilla'], range(3))))
# %%
'''(4) 세트 - {}'''
# 6-(4)-1
city_list = ["서울시", "경기도", "서울시", "인천시", "인천시", "서울시"]
print(set(city_list))
# %%
'''(5) 딕셔너리(사전) - {} '''
'''1) 딕셔너리 선언'''
# 6-(5)-1)-1
user_info = {"id": "aaaa", "pass": "123456", "name": "김왕쌍"}
print(user_info)
# %%
# 6-(5)-1)-2
score_info = {1: 100, 2: 200}
print(score_info)
# %%
# 6-(5)-1)-3
sys_dat = {'id': ('admin', 'root', 'dba'),
           'pass': ('1111', '2222', '3333'),
           'roll': (1, 2, 3)}

print(sys_dat)
# %%
'''2) 딕셔너리 사용'''
# 6-(5)-2)-1
print(user_info["id"])
print(score_info[1])
print(sys_dat['roll'])
# %%
# 6-(5)-2)-2
user_info = {"id": "aaaa", "pass": "123456", "name": "김왕쌍"}
user_info["id"] = "abcd"
print(user_info)
# %%
'''3) 딕셔너리 키 추가'''
# 6-(5)-3)-1
score_info = {1: 100, 2: 200}
score_info[3] = 300
print(score_info)
# %%
'''4) items()메소드 - 딕셔너리에서 키와 값을 같이 얻어냄'''
# 6-(5)-4)-1
dict3 = {5: 100, 15: 50, 90: 300}

for key, val in dict3.items():
    print(key, val)
# %%
'''5) keys()함수 - 딕셔너리의 키 추출'''
# 6-(5)-5)-1
dict3 = {5: 100, 15: 50, 90: 300}
dict3_keys = dict3.keys()
print(tuple(dict3_keys))
# %%
# 6-(5)-5)-2
# keys()함수 응용
admin_info = {'admin': '1111', 'root': '3333', 'dba': '2222'}
print(admin_info.keys())

origin_key = tuple(admin_info.keys())
print("admin_info 딕셔너리의 원래 키 :", origin_key)

print("admin_info딕셔너리에 새로운 키 abcd 추가")
admin_info['abcd'] = '1234'
admin_info_key = tuple(admin_info.keys())
print("admin_info 딕셔너리의 새로운 키 추가 후 :", admin_info_key)

print("원래 키와 새로운 키의 내용 같은가 비교 :", origin_key == admin_info_key)
# %%
'''6) dict()함수 - 딕셔너리타입으로 형변환'''
# 6-(5)-6)-1
dict1 = dict([('geralt', 150), ('yennefer', 100), ('cirilla', 20)])
print(dict1)

dict2 = dict(geralt=150, yennefer=100, cirilla=20)
print(dict2)
