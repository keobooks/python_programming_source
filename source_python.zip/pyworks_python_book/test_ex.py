# -*- coding: utf-8 -*-
# %%
'''3장 연습문제 정답'''
# %%
# 3장 5번
# 3장 5번 1항
val_float = 123.5
# %%
# 3장 5번 2항
data_a = 1
data_b = 2
# %%
# 3장 5번 3항
data_a, data_b = 1, 2
# %%
# 3장 5번 4항
user_id = "abcd"
user_pass = "123456"
# %%
'''4장 연습문제 정답'''
# %%
# 4장 1번
# 4장 1번 1항
str_val = input("입력:")
print(str_val)
# %%
# 4장 1번 2항
float_val = float(input("입력:"))
print(float_val)
# %%
# 4장 1번 3항
int_val = int(input("입력:"))
print(int_val)
# %%
# 4장 2번
data_num = input("번호 입력:")
data_name = input("이름 입력:")
data_age = int(input("나이 입력:"))

print(data_num, data_name, data_age)
# %%
# 4장 3번
data_score = map(float, input("5개의 점수를 입력: ").split())
print(list(data_score))
# %%
# 4장 4번
data_city = input("4개의 도시명을 입력 예)세종 과천 대구 전주: ").split()
print(data_city)
# %%
# 4장 5번
data_money = map(int, input("3개월 동안 받은 용돈 입력: ").split())
print(list(data_money))
# %%
# 4장 6번
data_count = map(int, input("5개 부서의 인원수 입력: ").split())
print(list(data_count))
# %%
'''5장 연습문제 정답'''
# %%
# 5장 2번
data_str = "bear"

# 5장 2번 1항
print("Good " + data_str)

# 5장 2번 2항
print(data_str * 3)

# 5장 2번 2항
print("-".join(data_str))
# %%
# 5장 3번
# 5장 3번 1항
print(max(167, 21, 18, 7, 1))
# %%
# 5장 3번 2항
print(min(167, 21, 18, 7, 1))
# %%
# 5장 3번 3항
print(len("En taro Adun!"))
# %%
# 5장 3번 4항
print("King" in "Ace of Spade")
# %%
# 5장 3번 5항
id_str = "960507-1234567"
print(id_str.replace(id_str[7:], "*******"))
# %%
# 5장 23번 6항
print("En taro Adun!".find("Adun"))
# %%
# 5장 3번 7항
print(" **good day** ".strip())
# %%
# 5장 4번
data_addr = input("주소 입력: ")
print(data_addr[:10])
# %%
# 5장 5번
inupt_no = input("번호 입력: ")
inupt_name = input("이름 입력: ")
inupt_scr = int(input("점수 입력: "))

print("%s,%s,%d" % (inupt_no, inupt_name, inupt_scr))
print("{0:s},{1:s},{2:d}".format(inupt_no, inupt_name, inupt_scr))
# %%
# 5장 6번
inupt_fn = input("파일명 입력: ")
file_ext_list = inupt_fn.split(".")

print(file_ext_list)
# %%
'''6장 연습문제 정답'''
# %%
# 6장 2번
data_str = ["월", "화", "수", "목", "금", "토", "일"]

# 6장 2번 1항
print(data_str[:3])

# 6장 2번 2항
print(data_str[5:])

# 6장 2번 3항
print(data_str[2:5])
# %%
# 6장 3번
data_str2 = ["월", "화", "화", "화", "금", "금"]

print(list(set(data_str2)))
# %%
# 6장 4번
w1_dict = {0: "일", 1: "월", 2: "화"}

# 6장 4번 1항
w1_dict[3] = "수"

# 6장 4번 2항
w1_dict[0] = "일요일"

# 6장 4번 3항
print(w1_dict)
# %%
# 6장 5번
ch_dict = {'geralt': 150, 'yennefer': 100, 'cirilla': 20}

# 6장 5번 1항
print(ch_dict['geralt'])

# 6장 5번 2항
print(tuple(ch_dict.keys()))

# 6장 5번 3항
print(list(ch_dict.items()))
# %%
# 6장 6번
rank_list = input("5개의 순위입력: ").split()
sta_list = input("5개의 역명입력: ").split()

print("rank_list리스트:", rank_list)
print("sta_list리스트:", sta_list)
# %%
# 6장 7번
mean_list = list(map(int, input("5개의 수송량입력: ").split()))

print("mean_list리스트:", mean_list)
# %%
# 6장 8번
tran_rank_dict = dict(rank=rank_list, sta=sta_list, mean=mean_list)

print("tran_rank_dict딕셔너리:", tran_rank_dict)
# %%
'''7장 연습문제 정답'''
# %%
# 7장 4번
a_list = [1, 0, 5, -3, 7]
a_sum = 0
for val in a_list:
    if val > 0:
        a_sum += val * 2
    else:
        a_sum += val
print(a_sum)
# %%
# 7장 5번
sum_val = 0
num_val = list(map(int, input("5개의 정수입력: ").split()))

for val in num_val:
    if val > 0:
        print(val, "양수")
        sum_val += val

print("양수합계:", sum_val)
# %%
# 7장 6번
purchase_list = []
stock_count = list(map(int, input("3개의 재고수량 입력: ").split()))

for val in stock_count:
    if val >= 1:
        purchase_list.append("구매가능")
    else:
        purchase_list.append("구매불가")

print(purchase_list)
# %%
# 7장 7번
station_dict = {}
sta_list = input("5개의 역명입력: ").split()

for index, val in enumerate(sta_list):
    station_dict[index] = val

print("station_dict 딕셔너리:", station_dict)
# %%
# 7장 8번
g_list = []

while True:
    g_str = input("성별 입력: ")
    if g_str == "q":
        print(g_list)
        break
    elif g_str == "남":
        g_list.append(1)
    elif g_str == "여":
        g_list.append(2)
# %%
# 7장 9번
one_val = 0
two_val = 0

for val in g_list:
    if val == 1:
        one_val += 1
    else:
        two_val += 1

print("1의 개수: %d, 2의 개수: %d" % (one_val, two_val))
# %%
# 7장 10번
while True:
    input_val = input("값 입력 q를 입력하면 중단: ")

    if input_val == "q":
        break

    input_val = int(input_val)
    if input_val >= 90:
        rating = "A"
    elif input_val >= 80:
        rating = "B"
    elif input_val >= 70:
        rating = "C"
    elif input_val >= 60:
        rating = "D"
    else:
        rating = "F"

    print("점수 : %d, 평가 : %s" % (input_val, rating))
# %%
'''8장 연습문제 정답'''
# %%
# 8장 2번
print(ord("A"))
print(sorted([167, 21, 18, 7, 1]))
print(sum([3, 4, 5, 6, 7]))
print(list(reversed([3, 4, 5, 6, 7])))
# %%
# 8장 3번
add_fun1 = (lambda x, y: x + y)
print(add_fun1(12, 30))
# %%
# 8장 4번
from random import choice


def choice_face():
    card_face = ["Hearts", "Diamonds", "Clubs", "Spades"]
    return choice(card_face)


def chice_num():
    card_num = ["Ace", "Deuce", "Three", "Four", "Five", "Six",
                "Seven", "Eight", "Nine", "Ten", "Jack", "Queen", "King"]
    return choice(card_num)

# %%
# 8장 5번
print("선택된 카드: %s of %s" % (chice_num(), choice_face()))
# %%
# 8장 6번
from random import randint


def five_nums():
    lo_list = list(range(1, 46))
    c_list = []

    for i in range(5):
        r_idx = randint(0, 45)
        c_list.append(lo_list[r_idx])
        lo_list.pop(r_idx)

    return sorted(c_list)
# %%
# 8장 7번
print("임의의 5개의 수 비복원 추출:", five_nums())
# %%
'''9장 연습문제 정답'''
# %%
# 9장 2번


class cleaner(object):
    def __init__(self, model, price):
        self.model = model
        self.price = price


# %%
# 9장 3번

class GameCharacter(object):
    def __init__(self, c_name, c_health, c_mana, role, haved_items):
        self.c_name = c_name
        self.c_health = c_health
        self.c_mana = c_mana
        self.role = role
        self.haved_items = haved_items

    def getCharacter(self):
        return dict(c_name=self.c_name, c_health=self.c_health, \
                    c_mana=self.c_mana, role=self.role, \
                    haved_items=self.haved_items)


# %%
# 9장 4번
user_chae = GameCharacter("연탄왕자", 300, 100, "영웅", {})

print(user_chae.getCharacter())
# %%
# 9장 5번


class CustomerInfo(object):
    def __init__(self, cus_no, cus_name, cus_grade):
        self.__cus_no = cus_no
        self.__cus_name = cus_name
        self.__cus_grade = cus_grade

    def getCustomer(self):
        return dict(cus_no=self.__cus_no, cus_name=self.__cus_name, \
                    cus_grade=self.__cus_grade)


# %%
# 9장 6번
cust = CustomerInfo("c1021", "홍길동", "A")

print(cust.getCustomer())
# %%
'''10장 연습문제 정답'''
# %%
# 10장 2번
with open("w_data.csv", "w") as f:
    f.write("name,age\ngeralt,150\nyennefer,100\ncirilla,20\n")
# %%
# 10장 3번
with open("w_data.csv", "r") as f:
    for line in f:
        print(line, end="")
# %%
# 10장 4번
import pandas as pd

df = pd.read_csv("w_data.csv")
print(df)
