# -*- coding: utf-8 -*-
# %%
'''Basic Grammar - ch04.py'''
''' 4. 화면 입출력 – 인터렉티브한 값 입력 및 출력'''
''' (1) 화면 입력 – input()함수 '''
# %%
# 4-(1)-1
input()
# %%
# 4-(1)-2
in_val = input("1~6사이의 값 입력: ")
in_val
# %%
'''1) 숫자 값 1개 입력 '''
# 4-(1)-1)-1
# 입력한 값을 정수로 반환
in_val = int(input("1~6사이의 값 입력: "))
in_val
# %%
# 4-(1)-1)-2
# 입력한 값을 부동소수점으로 반환
in_val2 = float(input("1~6사이의 값 입력: "))
in_val2
# %%
'''2) 문자열 값 1개 입력 '''
# 4-(1)-2)-1
user_id = input("아이디 입력: ")
user_id
# %%
# 4-(1)-2)-2
# 문자열로 형변환
var1 = 20
str(var1)
# %%
'''3) 문자열 값 여러 개 입력 '''
# 4-(1)-3)-1
# input()함수 여러개 사용
user_id = input("아이디 입력: ")
user_pass = input("비밀번호 입력: ")
print("아이디 : ", user_id, ", 비밀번호 : ", user_pass)
# %%
'''문제해결 4-1-1)'''
# 4-(1)-3)-2

# 순서1
data_name = input("이름 입력: ")

# 순서2
score_val = int(input("점수 입력: "))

# 순서3
print(data_name, score_val)
# %%
# 4-(1)-3)-3
# input()함수와 split()함수 결합
user_info = input("아이디와 비밀번호 입력- 예)aaaa 1111: ").split()
user_info
# %%
'''문제해결 4-1-2)'''
# 4-(1)-3)-4

# 순서1
data_strs = input("입력 예)black navy blue grey purple: ").split()

# 순서2
print(data_strs)
# %%
'''4) 숫자 값 여러 개 입력 '''
# 4-(1)-4)-1
# 여러 개의 정수 값 입력
int_values = map(int, input("정수값 3개 입력 - 예)1 2 3: ").split())
print(int_values)
print(list(int_values))

# %%
# 4-(1)-4)-2
# 여러 개의 부동소수점 값 입력
float_values = map(float, input("부동소수값 3개 입력- 예)1.5 2.3 3.1: ").split())
print(float_values)
print(list(float_values))
# %%
'''문제해결 4-1-2)'''
# 4-(1)-4)-3

# 순서1
data_ints = map(int, input("정수 값 2개 입력 예)12 30: ").split())

# 순서2
print(list(data_ints))
# %%
''' (2) 화면 출력 – print()함수 '''
# 4-(2)-1
user_id = "abcd"
user_pass = "1234"
print(user_id, user_pass)
# %%
# 4-(2)-2
# sep='_' 옵션을 사용해서 출력 값과 값 사이를 _구분자 표시
user_id = "abcd"
user_pass = "1234"
print(user_id, user_pass, sep="_")
# %%
# 4-(2)-3
# end=', ' 옵션을 사용한 출력 결과를 한 줄 로 표시
user_id = "abcd"
user_pass = "1234"
print("아이디 :", user_id, end=", ")
print("비밀번호 :", user_pass)
# %%
# 4-(2)-4
# 이스케이프 문자(escape character) 사용 예 - 큰 따옴표 겹쳐서 사용
print("\"En taro Adun\" is mean \"For Adun's name!\"")
# %%
# 4-(2)-5
# 이스케이프 문자(escape character) 사용 예
print('She\'s gone')
print("파일은 \"여기\"를 눌러 다운로드")
print("Winter Bear\\Scenery")
print("En taro Adun.\nVar en nas.")
print("\nEn taro Adun.\r")
print("En taro Adun.\tVar en nas.")
print("En taro Adun. \bVar en nas.")
print("8진수: \110\145\154\154\157")
print("16진수: \x48\x65\x6c\x6c\x6f")
# %%
# 4-(2)-6
# 이스케이프 문자(escape character) 사용 예 - 폼 피드 사용
print("\f")
print("En taro Adun.")
# %%
# 4-(2)-7
print("She's gone")
print('Billy "The good boy"')
