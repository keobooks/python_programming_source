# -*- coding: utf-8 -*-
# %%
'''3장 문제 정답'''
# %%
# 문제3-1
data_val = 5

print(data_val)  # 선언된 변수 확인할 경우 사용
# %%
# 문제3-2
data_str = "test"

print(data_str)  # 선언된 변수 확인할 경우 사용
# %%
# 문제3-3
data_val, data_str = 5, "test"

print(data_val, data_str)  # 선언된 변수 확인할 경우 사용
# %%
# 문제3-4
del data_val, data_str

# print(data_val, data_str)  # 없는 변수여서 출력시 에러발생
# %%
'''4장 문제 정답'''
# %%
# 문제4-1
input_str1 = input("문자열 입력:")

print(input_str1)  # 변수 확인할 경우 사용
# %%
# 문제4-2
input_int1 = int(input("정수 값 입력:"))

print(input_int1)  # 변수 확인할 경우 사용
# %%
# 문제4-3
input_float1 = float(input("실수 값 입력:"))

print(input_float1)  # 변수 확인할 경우 사용
# %%
# 문제4-4
data_name = input("이름 입력:")
data_kor = int(input("국어점수 입력:"))
data_math = int(input("수학점수 입력:"))
data_sci = int(input("과학점수 입력:"))

print(data_name, data_kor, data_math, data_sci)
# %%
# 문제4-5
data_name = input("이름 입력:")
data_kor = int(input("국어점수 입력:"))
data_math = int(input("수학점수 입력:"))
data_sci = int(input("과학점수 입력:"))

print(data_kor + data_math + data_sci)
print((data_kor + data_math + data_sci) / 3)
# %%
# 문제4-6
data_strs = input("입력 예)서울 경기 강원: ").split()

print(data_strs)
# %%
# 문제4-7
data_ints = map(int, input("입력 예)9 20 15 7 10: ").split())

print(list(data_ints))
# %%
# 문제4-8
data_floats = map(float, input("입력 예)19.95 12.3: ").split())

print(list(data_floats))
# %%
'''5장 문제 정답'''
# %%
# 문제5-1
import math

r = 5

print("원의 둘레 : ", 2 * math.pi * r)
print("원의 넓이 : ", r * r * math.pi)
# %%
# 문제5-2
print("최대값 :", max(7, 5, 10, 11, 8))
print("최소값 :", min(7, 5, 10, 11, 8))
# %%
# 문제5-3
print("4 * 4 * 4 :", pow(4, 3))
# %%
# 문제5-4
print("-1995.123의 절대값 :", abs(-1995.123))
# %%
# 문제5-5
print("19.95 올림 값 :", math.ceil(19.95))
print("19.95 내림 값 :", math.floor(19.95))
# %%
# 문제5-6
print("4와 9의 제곱근 :", math.sqrt(4), math.sqrt(9))
# %%
# 문제5-7
addr = input("주소 입력: ")

print("주소 :", addr)
# %%
# 문제5-8
ac_date = input("관측일 입력: ")
ac_place = input("지역 입력: ")
ac_count = int(input("발생수 값 입력: "))

print(ac_date + "," + ac_place + "," + str(ac_count))
# %%
# 문제5-9
nu_num = input("번호 입력: ")
nu_place = input("지점 입력: ")
nu_tac = int(input("저장용량 입력: "))
nu_ac = int(input("저장량 입력: "))

print(nu_num + "," + nu_place + "," + str(nu_tac) + "," + str(nu_ac))
# %%
# 문제5-10
input_str = input("반복할 문자열 입력: ")
re_cnt = int(input("횟수 입력: "))

print(input_str * re_cnt)
print((input_str * 3) + "app1" + (input_str * 3))
print(input_str * re_cnt)
# %%
# 문제5-11
print("Winter" in "Spring Summer Fall Winter")
# %%
# 문제5-12
input_str = input("문자열 입력: ")

print(input_str + " :", len(input_str))
# %%
# 문제5-13
input_str1 = input("문자열 입력: ")
input_str2 = input("문자열 입력: ")

print(input_str2.join(input_str1))
# %%
# 문제5-14
addr = "서울특별시 중구 명동 세종대로 110"

print(addr.split())
# %%
# 문제5-15
data_str = "서울시 종로구"
data_str.replace("서울시", "서울특별시")

print(data_str)
# %%
# 문제5-16
var1 = 5
var2 = 2
print("%d 나누기 %d 한 값의 결과는 %.1f" % (var1, var2, var1 / var2))
print("{0:d} 나누기 {1:d} 한 값의 결과는 {2:.1f}".format(var1, var2, var1 / var2))
# %%
# 문제5-17
input_local = input("지역 입력: ")
input_val = int(input("값 입력: "))

print("%s : %5d" % (input_local, input_val))
print("{0:s} : {1:5d}".format(input_local, input_val))
# %%
'''6장 문제 정답'''
# %%
# 문제6-1
city_list = ["서울", "경기", "인천"]
pop_list = [1, 1.2, 0.3]

print("city_list 리스트 :", city_list)
print("pop_list리스트 :", pop_list)
# %%
# 문제6-2
ol_list = []

ol_list.append(151.9)
ol_list.append(205.7)
ol_list.append(217.5)

print("ol_list_list 리스트 :", ol_list)
# %%
# 문제6-3
age_list = map(int, input("입력 예)150 100 20: ").split())

print("age_list 리스트 :", list(age_list))
# %%
# 문제6-4
city_list = ["서울", "경기", "인천"]
city_list[0] = "서울시"

print("city_list 리스트 :", city_list)
# %%
# 문제6-5
pop_list = [1, 1.2, 0.3]

print("pop_list[2]:", pop_list[2])
# %%
# 문제6-6
age_list = list(map(int, input("입력 예)150 100 20: ").split()))

print("age_list[0:2]:", age_list[0:2])
print("age_list[1:]:", age_list[1:])
# %%
# 문제6-7
ol_list.append(144.5)

print("ol_list_list 리스트 :", ol_list)
# %%
# 문제6-8
ol_list.insert(3, 169.2)

print("ol_list_list 리스트 :", ol_list)
# %%
# 문제6-9
print("11~19까지의 값의 범위 리스트 :", list(range(11, 20)))
# %%
# 문제6-10
print("0~30까지의 3의 배수 값의 범위 리스트 :", list(range(0, 31, 3)))
# %%
# 문제6-11
org_list = [1, 2, 3, 5, 8]
power_list = [x * x for x in org_list]

print("org_list을 제곱한 power_list리스트 :", power_list)
# %%
# 문제6-12
org_list2 = [1, 2, 3, 4, 5, 6]
mul_list = [x * x * x for x in org_list2 if x % 3 == 0]

print("3의 배수만 3제곱한 mul_list리스트 :", mul_list)
# %%
# 문제6-13
three_times_list = [1, 8, 27, 125, 512]

print(list(enumerate(three_times_list)))
# %%
# 문제6-14
org_list = [1, 2, 3, 5, 8]
three_times_list = [1, 8, 27, 125, 512]

print(list(zip(org_list, three_times_list)))
# %%
# 문제6-15
# 입력받을 값 예시: 402.1 404.3 408.8 411.8 413.2
co2_list = map(float, input("5개의 실수 입력: ").split())

# 입력받을 값 예시: 1920 1984 1991 1991 1980
ch4_list = map(int, input("5개의 정수 입력: ").split())

print(list(zip(co2_list, ch4_list)))
# %%
# 문제6-16
ext_tuple = (".jsp", ".php", ".asp", ".js")

print("ext_tuple튜플 :", ext_tuple)
# %%
# 문제6-17
week_list = ["월", "화", "수", "목", "금", "토", "일"]

print("튜플로 변환 :", tuple(week_list))
# %%
# 문제6-18
sub_list = ["1호선", "2호선", "2호선", "3호선", "2호선", "4호선", "4호선"]

print("중복제거 리스트 :", list(set(sub_list)))
# %%
# 문제6-19
article_dict = {"num": 100, "title": "test", "writer": "admin"}

print("article_dict딕셔너리 :", article_dict)
# %%
# 문제6-20
article_dict = {"num": 100, "title": "test", "writer": "admin"}
article_dict["writer"] = "관리자"

print("article_dict딕셔너리 :", article_dict)
# %%
# 문제6-21
article_dict["read_cnt"] = 1

print("article_dict딕셔너리 :", article_dict)
# %%
# 문제6-22
print("article_dict딕셔너리 키와 값:", article_dict.items())
# %%
# 문제6-23
no_list = [1, 2, 3]
game_list = ["SC", "WOW", "LOL"]
df_list = ["e", "n", "d"]

fav_dict = dict(no=no_list, game=game_list, df=df_list)

print("fav_dict딕셔너리 :", fav_dict)
# %%
'''7장 문제 정답'''
# %%
# 문제7-2
# 문제7-2-1
money = int(input("소지금 입력: "))

if money >= 18000:
    print("스킨구매")
else:
    print("기본스킨")
# %%
# 문제7-2-2
stock_count = int(input("재고수량 입력: "))

if stock_count >= 1:
    purchase = "구매가능"
else:
    purchase = "구매불가"

print("재고수량: {0:d}개, {1:s}".format(stock_count, purchase))

# %%
# 문제7-2-3
stage_stu = False

mission_count = int(input("완수한 미션개수 입력: "))
item_count = int(input("아이템 개수 입력: "))

if mission_count >= 5 and item_count >= 3:
    print("보스 스테지")
    stage_stu = True
else:
    print("현 스테이지 유지")

# %%
# 문제7-2-4
order_qnt = 100

stock_count = int(input("재고수량 입력: "))
dow_stu = bool(int(input("요일요소 입력예) 1또는 0: ")))

if stock_count < 50 or dow_stu:
    order_qnt *= 2

print("주문수량: %d, 재고수량: %d" % (order_qnt, order_qnt + stock_count))
# %%
# 문제7-3
# 문제7-3-1
num_val = int(input("숫자값 입력: "))

if num_val > 0:
    print("양수")
elif num_val < 0:
    print("음수")
elif num_val == 0:
    print("0")
# %%
# 문제7-3-2
stock_count = int(input("재고수량 입력: "))

if stock_count >= 10:
    print("구매 원할")
elif stock_count >= 1:
    print("품절 임박")
else:
    print("구매 불가")
# %%
# 문제7-3-3
g_code = input("성별 입력예)1~4: ")

if g_code == "1" or g_code == "3":
    print("남자")
elif g_code == "2" or g_code == "4":
    print("여자")
# %%
# 문제7-3-4
dow_var = int(input("요일 값(0~6) 입력: "))

if dow_var == 1:
    print("월요일", "평일")
elif dow_var == 2:
    print("화요일", "평일")
elif dow_var == 3:
    print("수요일", "평일")
elif dow_var == 4:
    print("목요일", "평일")
elif dow_var == 5:
    print("금요일", "불타는 금요일")
elif dow_var == 6:
    print("토요일", "주말")
elif dow_var == 0:
    print("일요일", "주말")
# %%
# 문제7-4
# 문제7-4-1
data_int = int(input("정수 입력: "))

eo_str = "홀수" if data_int % 2 == 1 else "짝수"

print("입력 값: %d, %s" % (data_int, eo_str))
# %%
# 문제7-4-2
input_id = input("아이디 입력: ")

check_id = 0 if input_id == "admin" else 1

print("입력 값: %s, %d" % (input_id, check_id))
# %%
# 문제7-5
# 문제7-5-1
num_val = map(int, input("정수 입력: ").split())

for val in num_val:
    if val > 0:
        print("양수")
    elif val < 0:
        print("음수")
    elif val == 0:
        print("0")
# %%
# 문제7-5-2
product_dict = {}

product_code = input("상품코드 입력 : ").split()
product_pricet = map(int, input("상품가격 입력 : ").split())

for key, val in zip(product_code, product_pricet):
    product_dict[key] = val

print(product_dict)
# %%
# 문제7-5-3
from random import randrange

rew_list = ["뉴스킨", "울트라스킨", "어썸스킨"]

rank_jum = map(int, input("랭크점수 입력 : ").split())

for val in rank_jum:
    if val >= 90:
        rank_str = "골드"
    elif val >= 70:
        rank_str = "실버"
    else:
        rank_str = "브론즈"

print("등급: %s, 보상상품: %s" % (rank_str, rew_list[randrange(3)]))
# %%
# 문제7-6
# 문제7-6-1

sum_plus = 0
sum_minus = 0

while True:
    num_val = int(input("정수 입력: "))

    if num_val == 0:
        print("양수합계: %d, 음수합계: %d" % (sum_plus, sum_minus))
        break

    if num_val > 0:
        sum_plus += num_val
    else:
        sum_minus += num_val
# %%
# 문제7-6-2

while True:
    input_str = input("문자열 리스트 입력: ")

    if input_str == "q":
        break
    else:
        input_str = input_str.split()

    for data in input_str:
        if data == "bear":
            print("bear")
            break
# %%
# 문제7-6-3
from random import randrange

crush_stu = True

# 순서2
health_val = int(input("초기체력 입력: "))
health_val = health_val if health_val >= 0 else 0

# 순서3
while True:
    if health_val == 0:
        print("game over!!")
        break
    if crush_stu:
        crush_val = randrange(500)
        health_val -= crush_val
        health_val = health_val if health_val >= 0 else 0
        print("충돌: %d, 남은 체력: %d" % (crush_val, health_val))
# %%
'''8장 문제 정답'''
# %%
# 문제8-1
grade_list = ["3학년", "1학년", "2학년", "4학년", "3학년","2학년"]
# %%
# 문제8-1-1
print("grade_list의 원소 개수: %d" % (len(grade_list)))
# %%
# 문제8-1-2
sorted_list = sorted(grade_list)
print("sorted_list :", sorted_list)
# %%
# 문제8-1-3
print("sorted_list역순 :", list(reversed(sorted_list)))
# %%
# 문제8-2
val_list = [10, 20, 30, 40, 50]
# %%
# 문제8-2-1
print("val_list의 합: %d" % (sum(val_list)))
# %%
# 문제8-2-2
print("val_list의 최대값: %d, 최소값: %d" % (max(val_list), min(val_list)))
# %%
# 문제8-2-3
pos = slice(2, 5)
part_list = val_list[pos]
print("part_list :", part_list)
# %%
# 문제8-3
c_list = ["x", "s", "n", "t", "p", "f", "c", "n"]
i_list = [ord(x) for x in c_list]

print("c_list :", c_list)
print("i_list :", i_list)
# %%
# 문제8-4


def sorted_list(list_val):
    return sorted([x * 2 for x in list_val if x % 2 == 0])


# %%
# 문제8-5


def new_list(list_val1, list_val2):
    return [x * y for x, y in zip(list_val1, list_val2)]


# %%
# 문제8-6
print("sorted_list()함수 실행:", sorted_list(range(1, 21)))
# %%
# 문제8-7
print("new_list()함수 실행:", new_list(range(1, 11, 2), range(2, 11, 2)))
# %%
'''9장 문제 정답'''
# %%
# 문제9-1


class ArticleInfo(object):
    def __init__(self, id_num, passd, title, writer, content):
        self.id_num = id_num
        self.passd = passd
        self.title = title
        self.writer = writer
        self.content = content

    def getArticle(self):
        return dict(id_num=self.id_num, passd=self.passd, \
                    title=self.title, writer=self.writer, content=self.content)


# %%
# 문제9-2


class Robot(object):
    def __init__(self, shape, position, direction, speed):
        self.shape = shape
        self.position = position
        self.direction = direction
        self.speed = speed

    def move(self, direction, move_pos, speed):
        return dict(direction=direction, position=move_pos, speed=speed)


# %%
# 문제9-3
use_article = ArticleInfo(1, "123", "테스트", "관리자", "테스트입니다")

print(use_article.getArticle())
# %%
# 문제9-4
use_robot = Robot("구형", [0, 0, 0], [0, 0, 0], 0)

print(use_robot.move([100, 10, 20], [30, 70, 40], 10))
# %%
'''10장 문제 정답'''
# %%
# 문제10-1
with open("data01.txt", "r") as f:
    for line in f:
        print(line, end="")
# %%
# 문제10-2
with open("AceofSpades.png", "rb") as f:
    for line in f:
        print(line)
# %%
# 문제10-3
import cv2
import matplotlib.pyplot as plt

# 순서3
img = cv2.imread("AceofSpades.png", cv2.IMREAD_COLOR)

# 순서4
b, g, r = cv2.split(img)
img_cov = cv2.merge([r, g, b])

# 순서5
plt.imshow(img_cov)

# 순서6
plt.xticks([])
plt.yticks([])
plt.show()
# %%
# 문제10-4
import pandas as pd

df_trns = pd.read_csv("20200521_2017년서울교통공사수송순위.csv",
                      encoding="cp949", engine="python")
print(df_trns)
