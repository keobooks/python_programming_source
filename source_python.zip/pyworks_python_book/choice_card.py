# -*- coding: utf-8 -*-
# %%
from random import choice


def choice_face():
    card_face = ["Hearts", "Diamonds", "Clubs", "Spades"]
    return choice(card_face)


def chice_num():
    card_num = ["Jack", "Queen", "King"]
    return choice(card_num)
