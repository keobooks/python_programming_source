# -*- coding: utf-8 -*-
# %%
'''Basic Grammar - ch08.py'''
'''8. 함수와 모듈'''
'''(1) 함수개요'''
# %%
# 8-(1)-1
import datetime

print("오늘날짜와 현재시간 :", datetime.datetime.now())
# %%
# 8-(1)-2
input_data = input("숫자값 입력: ")

print("입력값 : " + input_data)
print("입력값 * 2 :", float(input_data) * 2)
# %%
# 8-(1)-3
input_val = int(input("숫자값 입력: "))
print(input_val)
# %%
'''(2) 내장함수'''
# 8-(2)-1
# id(), chr(), ord() 함수 사용
var1 = 1230
print(var1, "값의 id :", id(var1))

print("A의 코드 값 :", ord("A"))
print("97코드의 문자 값 :", chr(97))
# %%
# 8-(2)-2
# sum(), len() 함수 사용
val_list = [1995, 12, 30]
print(val_list)
print("리스트의 원소수:", len(val_list), ", 원소값의 합:", sum(val_list))
# %%
# 8-(2)-3
# slice(), sorted(), reversed() 함수 사용
bear_list = ["네시", "scenery", "winter bear", "sweet night", "snow flower"]
print("원래 리스트:", bear_list)
pos = slice(2, 5)
print("2번째 원소부터 끝까지 슬라이스: ", bear_list[pos])

print("\n원래 리스트:", bear_list)
print("리스트 정렬:", sorted(bear_list))

print("\n원래 리스트:", bear_list)
print("리스트 역순:", list(reversed(bear_list)))
# %%
'''(3) 사용자 정의 함수 작성 및 사용'''
'''1) 사용자 정의 함수 작성: def'''
# 8-(3)-1)-1
# 2개의 매개변수 값을 더한 후 값을 반환하는 함수 작성


def add_data(a, b):
    return a + b


# %%
# 8-(3)-1)-2
# 매개변수없고 반환 값도 없는 함수 작성


def test():
    var1 = 20
    print(var1)


# %%
# 8-(3)-1)-3
'''문제해결 8-1-1)'''
# 순서1


def square_val(list_val):
    print("원래 리스트 :", list_val)
    print("원래 값 제곱한 결과 : ", end=" ")
    for val in list_val:
        print("%.2f" % (val * val), end=" ")


# %%
# 8-(3)-1)-4
'''문제해결 8-1-2)'''
# 순서1


def make_dict(key_val, list_val):
    result_dict = {}
    for key, val in zip(key_val, list_val):
        result_dict[key] = val
    return result_dict


# %%
'''2) 사용자 정의 함수 사용'''
# 8-(3)-2)-1
# add_data(x, y) 사용자 정의 함수 호출해서 사용

# 순서1
input_x = int(input("정수 값1 입력: "))
input_y = int(input("정수 값2 입력: "))

# 순서2
print("add_data(input_x, input_y)함수실행 결과:", add_data(input_x, input_y))
# %%
# 8-(3)-2)-2
# test() 사용자 정의 함수 호출해서 사용

# 순서1
test()
# %%
# 8-(3)-2)-3
'''문제해결 8-2-1)'''
# square_val(list_org) 사용자 정의 함수 호출해서 사용

# 순서1
list_org = [10.1, 7.3, 9.6, 5.2, 6.8]

# 순서2
square_val(list_org)
# %%
# 8-(3)-2)-4
'''문제해결 8-2-2)'''
# make_dict(tuple_org, list_org) 사용자 정의 함수 호출해서 사용

# 순서1
tuple_org = ("v1", "v2", "v3")
list_org = [[1, 2, 3], [4, 5, 6], [7, 8, 9]]

# 순서2
print(make_dict(tuple_org, list_org))
# %%
# 8-(3)-3)-1


def func_varg(x, y, *args, **kwargs):
    print(x, y, args, kwargs)


# %%
# 8-(3)-3)-2
func_varg(7, 'key', 5, 31.4, v=2, h='test')
# %%
'''(4) 변수의 유효범위: 전역변수와 지역변수'''
# 8-(4)-1

var1 = 10  # 전역변수 var1


def test_var():
    var1 = 20  # 지역변수 var1
    print("지역변수 var1 출력")
    print("함수안에서 var1변수 출력:", var1)


test_var()
print("\n전역변수 var1 출력")
print("함수밖에서 var1변수 출력:", var1)
# %%
'''(5) 람다(lambda)식 : 익명함수 작성 기능'''
# 8-(5)-1

lam_func1 = (lambda x, y: x * x + y)
print(lam_func1(5, 7))
# %%
# 8-(5)-2


def lam_test1(lam_func2):
    print(lam_func2(5, 7))


lam_test1(lambda x, y: x * x + y)
# %%
# 8-(5)-3


def multiple_func(n):
    return lambda x: x * n


mul_dbl = multiple_func(2)
print("원래값 2배함수 사용 :", mul_dbl(10))

mul_trp = multiple_func(3)
print("원래값 3배함수 사용 :", mul_trp(10))
# %%
'''(6)모듈(라이브러리, 패키지) 로드 : import 라이브러리명'''
'''1) 모듈 로드 및 사용 방법'''
# 8-(6)-1)-1

import random

print(random.randrange(1, 7))
# %%
# 8-(6)-1)-2

import random as r

print(r.randrange(1, 7))
# %%
# 8-(6)-1)-3

from random import randrange

print(randrange(1, 7))
# %%
'''2) 자신만의 모듈(라이브러리) 작성 및 사용'''
# 8-(6)-2)-2

from lib_test import my_mul, my_val

val1 = int(input("값1 입력: "))
val2 = int(input("값2 입력: "))

print(my_mul(val1, val2) + my_val())
