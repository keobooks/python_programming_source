# -*- coding: utf-8 -*-
# %%
'''Basic Grammar - ch03.py'''
''' 3. 변수와 연산자 - 값 저장 및 기본 처리'''
''' (1) 변수 - 재사용할 값 저장소 '''
# %%
'''1) 변수선언 '''
# 3-(1)-1)-1
# 변수 선언
a = 5
# %%
# 3-(1)-1)-2
# 정수값을 갖는 숫자변수 선언
age = 20
age
# %%
# 3-(1)-1)-3
# 문지열변수 선언
str2 = 'abc'
str2
# %%
# 3-(1)-1)-4
# 문지열변수 선언
str2 = 'abc'
print(str2)
# %%
# 3-(1)-1)-5
user_age = 0  # 숫자 변수 선언
user_age
# %%
# 3-(1)-1)-6
user_name = '김씨'  # 문자열 변수 선언
user_name
# %%
# 3-(1)-1)-7
user_age = 22  # 변수값 변경
user_age
# %%
# 3-(1)-1)-8
# 리스트변수 선언
my_list = [1, 2, 'a']
my_list
# %%
# 3-(1)-1)-9
# 튜플변수 선언
my_tuple = (1, 2, 'a')
my_tuple
# %%
# 3-(1)-1)-10
# 딕셔너리변수 선언
my_dic = {"id": "abcd", "jum": 80}
my_dic
# %%
# 3-(1)-1)-11
# 함수 선언
fun_a = (lambda x, y: x * x + y)
fun_a(2, 3)
# %%
# 3-(1)-1)-12
# 2개의 변수를 같은 줄에서 선언
user_id, user_passwd = "aaaa", "1234"
print(user_id, user_passwd)
# %%
'''2) 변수 제거 '''
# 3-(1)-2)-1
del age
# %%
''' (2) 연산자 - 연산자를 사용한 값 처리 '''
'''1) 산술연산자 '''
# 3-(2)-1)-1
x, y = 7, 2
print("x =", x, ", y =", y)
print("x + y = ", x + y)
print("x - y = ", x - y)
print("x * y = ", x * y)
print("x / y = ", x / y)
print("x % y = ", x % y)
print("x ** y = ", x ** y)
print("x // y = ", x // y)

# %%
'''2) 할당(대입)연산자 '''
# 3-(2)-2)-1
x, y = 7, 2
print("x =", x, ", y =", y)
x += y
print("x += y : ", x)

x, y = 7, 2
print("x =", x, ", y =", y)
x -= y
print("x -= y : ", x)

x, y = 7, 2
print("x =", x, ", y =", y)
x *= y
print("x *= y : ", x)

x, y = 7, 2
print("x =", x, ", y =", y)
x /= y
print("x /= y : ", x)

x, y = 7, 2
print("x =", x, ", y =", y)
x %= y
print("x %= y : ", x)

x, y = 7, 2
print("x =", x, ", y =", y)
x **= y
print("x **= y : ", x)

x, y = 7, 2
print("x =", x, ", y =", y)
x //= y
print("x //= y : ", x)
# %%
# 3-(2)-2)-2
# x += y 성능테스트

# 앞의 주석제거 후 [ipython console]창에 복사해서 실행
# %timeit x, y = 7, 2; x += y
# %%
# 3-(2)-2)-3
# x = x + y 성능테스트

# 앞의 주석제거 후 [ipython console]창에 복사해서 실행
# %timeit x, y = 7, 2; x = x + y
# %%
'''3) 비교(관계)연산자 '''
# 3-(2)-3)-1
x, y = 7, 2
print("x =", x, ", y =", y, ", x > y : ", x > y)
print("x =", x, ", y =", y, ", x < y : ", x < y)
print("x =", x, ", y =", y, ", x >= y : ", x >= y)
print("x =", x, ", y =", y, ", x <= y : ", x <= y)
print("x =", x, ", y =", y, ", x == y : ", x == y)
print("x =", x, ", y =", y, ", x != y : ", x != y)

# %%
# 3-(2)-3)-2
# 문자열비교
str1 = "LCK"
print("str1 == 'LCK' : ", str1 == 'LCK')
print("str1 == 'lck' : ", str1 == 'lck')

# %%
'''4) 논리연산자 '''
# 3-(2)-4)-1
var1, var2 = 7, 2
var3, var4 = True, False
print("var1 =", var1, ", var2 =", var2, ", var3 =", var3, ", var4 =", var4)
print("var3 and var4 : ", var3 and var4)
print("var3 or var4 : ", var3 or var4)
print("var1 >= 8 and var2 < 3 : ", var1 >= 8 and var2 < 3)
print("var1 >= 8 or var2 < 3 : ", var1 >= 8 or var2 < 3)
print("not var3 : ", not var3)

# %%
'''5) 비트연산자 '''
# 3-(2)-5)-1
var1, var2 = 8, 0
print("var1 =", var1, ", var2 =", var2, ", var1 & var2 : ", var1 & var2)
print("var1 =", var1, ", var2 =", var2, ", var1 | var2 : ", var1 | var2)
print("var1 =", var1, ", ~var1 : ", ~var1)
print("var1 =", var1, ", var2 =", var2, ", var1 ^ var2 : ", var1 ^ var2)
print("var1 =", var1, ", var1 << 1: ", var1 << 1)
print("var1 =", var1, ", var1 >> 1: ", var1 >> 1)
# %%
'''6) in연산자 '''
# 3-(2)-6)-1
var1 = 3
val_list = [1, 2, 3, 'a', True]
print("var1 =", var1, ", val_list =", val_list, ", var1 in val_list : ",
      var1 in val_list)
print("val_list =", val_list, ", False in val_list : ", False not in val_list)

# %%
'''7) is연산자 '''
# 3-(2)-7)-1
# id()함수
x = 10
print("id(x) : ", id(x))
# %%
# 3-(2)-7)-2
# is, not is 연산자
x = 10
y = 10
print("x :", x, ", x :", y, ", id(x) :", id(x), ", id(y) :", id(y))
print("x is y : ", x is y)
z = 20
print("x :", x, ", z :", z, ", id(x) :", id(x), ", id(z) :", id(z))
print("x is not z : ", x is not z)
