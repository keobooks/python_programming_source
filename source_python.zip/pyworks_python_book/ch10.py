# -*- coding: utf-8 -*-
# %%
'''Basic Grammar - ch10.py'''
'''10. 파일 입출력'''
'''(2) 파일 입출력 '''
# %%
'''1) with문과 open()함수를 사용한 텍스트 파일 읽고 쓰기'''
# 10-(2)-1)-1

with open("winterbear.txt", "r") as f:
    for line in f:
        print(line, end="")
# %%
# 10-(2)-1)-2

with open("protoss_heroes.txt", "w") as f:
    f.write("Fenix\nTassadar\nZeratul\nArtanis\n")
# %%
# 10-(2)-1)-3

with open("20200511_ghg.csv", "r") as f:
    for line in f:
        print(line, end="")
# %%
'''2) with문과 open()함수를 사용한 바이너리 파일 읽고 쓰기'''
# 10-(2)-2)-1
# 바이너리파일 읽기

with open("cover_s.png", "rb") as f:
    for line in f:
        print(line)
# %%
# 10-(2)-2)-2
# 바이너리파일 읽고 쓰기

with open("cover_s.png", "rb") as f1, open("cover_s_copy.png", "wb") as f2:
    for line in f1:
        f2.write(line)
# %%
# 10-(2)-2)-3
# 순서1. 패키지 설치
# 순서2
import cv2

# 순서3
img = cv2.imread("cover_s_copy.png")

# 순서4
cv2.imshow("img", img)
cv2.waitKey(0)
cv2.destroyAllWindows()
# %%
# 10-(2)-2)-4
# 순서1. 패키지 설치
# 순서2
import cv2
import matplotlib.pyplot as plt

# 순서3
img = cv2.imread("cover_s_copy.png", cv2.IMREAD_COLOR)

# 순서4
b, g, r = cv2.split(img)
img_cov = cv2.merge([r, g, b])

# 순서5
plt.imshow(img_cov)

# 순서6
plt.xticks([])
plt.yticks([])
plt.show()
# %%
import cv2
import matplotlib.pyplot as plt

img = cv2.imread("cover_s_copy.png")
plt.imshow(img)
# %%
# 10-(2)-2)-5
'''문제해결 10-2-1)'''

# 순서1
import cv2
import choice_card as card

# 순서2
f_name = "img/" + card.chice_num() + "of" + card.choice_face() + ".png"

# 순서3
img = cv2.imread(f_name)

# 순서4
cv2.imshow("img", img)
cv2.waitKey(0)
cv2.destroyAllWindows()
# %%
'''3) 데이터 파일 입출력'''
# 10-(2)-3)-1
import pandas as pd

df_ozone = pd.read_csv("ozone_data.csv")
print(df_ozone)

# %%
# 10-(2)-3)-2
df_subway2 = pd.read_csv("20200423_202002_서울지하철승하차인원수.csv",
                         encoding="cp949", engine="python")
print(df_subway2)
# %%
# 10-(2)-3)-3
df_ol = pd.read_excel("20210104_2020년서울시구별노령화지수.xlsx")

print(df_ol)
